package com.example.demo.Repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.Entity.SD_Seller;

public interface SD_SellerRepository extends JpaRepository<SD_Seller, String>{

	Page<SD_Seller> findAll(Pageable pageabel);
}
