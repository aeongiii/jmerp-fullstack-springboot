package com.example.demo.security;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ERP_signUpForm {
	
	private String userId;
	
	private String password;
	
	private String name;
	
	private String employeeId;
}
