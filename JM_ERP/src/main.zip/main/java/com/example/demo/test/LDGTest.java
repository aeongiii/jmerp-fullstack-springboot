package com.example.demo.test;

public class LDGTest {
	// 연결완료
}
