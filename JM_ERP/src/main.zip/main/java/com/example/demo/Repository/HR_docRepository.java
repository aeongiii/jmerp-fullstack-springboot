package com.example.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.Entity.HR_doc;

public interface HR_docRepository extends JpaRepository<HR_doc, String>{

}