package com.example.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.Entity.PD_QC;

public interface PD_QCRepository extends JpaRepository<PD_QC, Integer>{

}
