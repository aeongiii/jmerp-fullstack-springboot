package com.example.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.Entity.PD_res;

public interface PD_resRepository extends JpaRepository<PD_res,String>{

}
