package com.example.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.Entity.BOM;

public interface BOMRepository extends JpaRepository<BOM, String>{

}
