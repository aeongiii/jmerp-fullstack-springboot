package com.example.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.Entity.PD_WO;

public interface PD_WORepository extends JpaRepository<PD_WO,String>{

}
